# Gece Karartma (Android)

Bu proje, Android'de sistem parlaklığının altına inmek için ekranın üzerine siyah, dokunmaları engellemeyen bir katman koyar.

## Özellikler
- %0–90 arası karartma seviyesi
- Uygulama kapatılsa da çalışan ön plan servisi
- Bildirimden karartmayı kapatma
- Android 6.0 ve üzeri hedeflenmiştir

## Derleme
1. Android Studio'da bu klasörü aç.
2. Gradle senkronizasyonunu tamamla (Android SDK 35 ve JDK 17 gerekir).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Telefonda ilk kullanım
1. Uygulamayı aç ve “Karartmayı başlat” düğmesine bas.
2. Android ayarlarında **Diğer uygulamaların üzerinde göster** iznini etkinleştir.
3. Uygulamaya dönüp yeniden “Karartmayı başlat” de.
4. Kaydırıcıdan istediğin karartmayı seç. Bildirimdeki “Kapat” düğmesi katmanı kaldırır.

Not: Bu uygulama gerçek ekran parlaklığını değiştirmez; ekranın üzerine siyah filtre uygular. Bazı video/oyun/HDR içeriklerinde görüntü farklı davranabilir. Çok yüksek karartmada ekranı görmek zorlaşabilir. Erişilebilirlik ve güvenlik ekranlarında Android bazı overlay'leri otomatik gizleyebilir.
