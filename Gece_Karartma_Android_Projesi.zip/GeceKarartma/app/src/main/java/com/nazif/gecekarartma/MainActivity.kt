package com.nazif.gecekarartma

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var valueText: TextView
    private lateinit var seek: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 28)
        window.navigationBarColor = Color.rgb(15, 18, 28)
        buildUi()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(Color.rgb(15, 18, 28))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply {
                this.text = text; textSize = size; setTextColor(color)
                gravity = Gravity.CENTER
            }

        layout.addView(label("GECE KARARTMA", 25f))
        layout.addView(label("Telefonun minimum parlaklığından daha fazla karart.", 14f, 0xFFB8C0D0.toInt()).apply {
            setPadding(0, 14, 0, 30)
        })

        valueText = label("Karartma: %45", 20f)
        layout.addView(valueText)

        seek = SeekBar(this).apply {
            max = 90
            progress = getSharedPreferences("dimmer", MODE_PRIVATE).getInt("level", 45)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    valueText.text = "Karartma: %$progress"
                    getSharedPreferences("dimmer", MODE_PRIVATE).edit().putInt("level", progress).apply()
                    sendBroadcast(Intent(DimmerService.ACTION_UPDATE).setPackage(packageName))
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        layout.addView(seek, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val start = Button(this).apply {
            text = "Karartmayı başlat"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                    Toast.makeText(this@MainActivity, "Gece Karartma için diğer uygulamaların üzerinde gösterme izni ver.", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, DimmerService::class.java))
                    Toast.makeText(this@MainActivity, "Karartma açıldı", Toast.LENGTH_SHORT).show()
                }
            }
        }
        layout.addView(start, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val stop = Button(this).apply {
            text = "Karartmayı kapat"
            setOnClickListener { stopService(Intent(this@MainActivity, DimmerService::class.java)) }
        }
        layout.addView(stop, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        layout.addView(label("İpucu: %70–90 gece kullanımında çok karanlık olabilir. İstediğin seviyeyi kaydırarak ayarla.", 13f, 0xFFB8C0D0.toInt()).apply {
            setPadding(0, 28, 0, 0)
        })
        setContentView(layout)
        valueText.text = "Karartma: %${seek.progress}"
    }
}
