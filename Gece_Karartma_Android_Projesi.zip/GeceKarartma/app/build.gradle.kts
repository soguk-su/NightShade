plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nazif.gecekarartma"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nazif.gecekarartma"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
