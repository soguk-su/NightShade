plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nazif.nightshade"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nazif.nightshade"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
