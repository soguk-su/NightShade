# NightShade

Samsung A30 / Android 11 için basit ekran karartma uygulaması.

## Özellikler
- Ekranın üzerine siyah filtre yerleştirerek sistem minimum parlaklığının altına iner.
- %0–100 karartma kaydırıcısı.
- Bildirim üzerinden kapatma.
- İnternet izni yoktur.

## APK oluşturma (telefonla, GitHub Actions)
1. GitHub'da yeni bir repository oluştur.
2. Bu klasördeki dosyaları ve klasör yapısını repository'ye yükle.
3. Repository > Actions > "Build NightShade APK" > Run workflow seç.
4. İşlem tamamlanınca oluşan çalıştırmaya gir ve Artifacts bölümünden `NightShade-debug-apk` dosyasını indir.
5. ZIP'i açıp `app-debug.apk` dosyasını telefona kur.

Not: Overlay izni gereklidir. %100 karartma ekranı tamamen siyah yapabilir; uygulamanın devam eden bildirimi içindeki Kapat düğmesiyle kapatılabilir. Android bazı güvenli ekranlarda overlay katmanını gizleyebilir. Bu proje derlenmiş APK değildir; kaynak projedir.
