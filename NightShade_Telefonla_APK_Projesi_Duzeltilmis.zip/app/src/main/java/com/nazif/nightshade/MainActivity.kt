package com.nazif.nightshade

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var valueText: TextView
    private lateinit var seek: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 15, 24)
        window.navigationBarColor = Color.rgb(12, 15, 24)
        buildUi()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(Color.rgb(12, 15, 24))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
            }

        layout.addView(label("NIGHTSHADE", 27f))
        layout.addView(label("Sistem parlaklığının altına in. Gece ekranını rahatça karart.", 14f, 0xFFB8C0D0.toInt()).apply {
            setPadding(0, 14, 0, 28)
        })

        valueText = label("Karartma: %0", 21f)
        layout.addView(valueText)

        seek = SeekBar(this).apply {
            max = 100
            progress = getSharedPreferences("dimmer", MODE_PRIVATE).getInt("level", 35)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    valueText.text = "Karartma: %$progress"
                    getSharedPreferences("dimmer", MODE_PRIVATE).edit().putInt("level", progress).apply()
                    sendBroadcast(Intent(DimmerService.ACTION_UPDATE).setPackage(packageName))
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        layout.addView(seek, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        layout.addView(Button(this).apply {
            text = "Karartmayı başlat"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    Toast.makeText(this@MainActivity, "NightShade için diğer uygulamaların üzerinde gösterme iznini aç.", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, DimmerService::class.java))
                    Toast.makeText(this@MainActivity, "Karartma açıldı", Toast.LENGTH_SHORT).show()
                }
            }
        }, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        layout.addView(Button(this).apply {
            text = "Karartmayı kapat"
            setOnClickListener { stopService(Intent(this@MainActivity, DimmerService::class.java)) }
        }, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        layout.addView(label("Not: %100 ekranı tamamen siyaha yaklaştırır. Kapatmak için bildirimdeki Kapat düğmesini kullanabilirsin.", 13f, 0xFFB8C0D0.toInt()).apply {
            setPadding(0, 26, 0, 0)
        })
        setContentView(layout)
        valueText.text = "Karartma: %${seek.progress}"
    }
}
