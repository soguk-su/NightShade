package com.nazif.nightshade

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout

class DimmerService : Service() {
    private var overlay: View? = null
    private lateinit var wm: WindowManager

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { updateAlpha() }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        registerReceiver(receiver, IntentFilter(ACTION_UPDATE))
        createNotification()
        showOverlay()
    }

    private fun createNotification() {
        val channelId = "nightshade_dimmer"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "NightShade karartma", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, DimmerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                     else Notification.Builder(this)
        val notification = builder
            .setContentTitle("NightShade açık")
            .setContentText("Karartmayı kapatmak için Kapat'a dokun.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(null, "Kapat", stopIntent).build())
            .setOngoing(true)
            .build()
        startForeground(7, notification)
    }

    private fun showOverlay() {
        if (overlay != null) return
        overlay = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(overlay, params)
        updateAlpha()
    }

    private fun updateAlpha() {
        val level = getSharedPreferences("dimmer", MODE_PRIVATE).getInt("level", 35)
        overlay?.alpha = level.coerceIn(0, 100) / 100f
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (overlay == null) showOverlay()
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.nazif.nightshade.UPDATE"
        const val ACTION_STOP = "com.nazif.nightshade.STOP"
    }
}
